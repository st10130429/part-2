using System;
using System.Collections.Generic;
using System.Linq;

namespace CybersecurityChatbot
{
    // ─── Delegates ───────────────────────────────────────────────────────────────
    public delegate void ResponseGeneratedHandler(string response, SentimentType sentiment);

    // ─── Enums ────────────────────────────────────────────────────────────────────
    public enum SentimentType
    {
        Neutral,
        Worried,
        Curious,
        Frustrated,
        Positive
    }

    // ─── Memory Store ─────────────────────────────────────────────────────────────
    public class UserMemory
    {
        public string Name { get; set; } = string.Empty;
        public string FavouriteTopic { get; set; } = string.Empty;
        public List<string> MentionedTopics { get; set; } = new List<string>();
        public string LastTopic { get; set; } = string.Empty;
        public int QuestionCount { get; set; } = 0;
    }

    // ─── ChatBot Class ────────────────────────────────────────────────────────────
    public class ChatBot
    {
        // Event using delegate (Part 2 requirement)
        public event ResponseGeneratedHandler OnResponseGenerated;

        private readonly Random _random = new Random();
        private readonly UserMemory _memory = new UserMemory();

        // ── Keyword → multiple responses (arrays/lists for random selection) ──────
        private readonly Dictionary<string, List<string>> _keywordResponses =
            new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase)
            {
                ["password"] = new List<string>
                {
                    "Make sure to use strong, unique passwords for each account. Avoid using personal details in your passwords.",
                    "A strong password should be at least 12 characters, mixing upper/lowercase letters, numbers, and symbols.",
                    "Consider using a password manager to generate and store complex passwords securely.",
                    "Never reuse passwords across multiple sites — a breach on one site could compromise all your accounts."
                },
                ["phishing"] = new List<string>
                {
                    "Be cautious of emails asking for personal information. Scammers often disguise themselves as trusted organisations.",
                    "Always verify the sender's email address before clicking any links — phishing emails often use lookalike domains.",
                    "Legitimate organisations will never ask for your password or sensitive info via email.",
                    "Watch out for urgency tactics — phishing emails often create panic to make you act without thinking."
                },
                ["scam"] = new List<string>
                {
                    "If something feels too good to be true, it probably is. Always verify before sharing personal information.",
                    "Scammers often impersonate banks, government agencies, or tech support. Always call official numbers to verify.",
                    "Never send money or gift cards to someone you haven't met in person — this is a classic scam red flag.",
                    "Report scams to your local consumer protection authority to help protect others."
                },
                ["privacy"] = new List<string>
                {
                    "Review your social media privacy settings regularly to control who can see your information.",
                    "Be mindful of what personal information you share online — even small details can be pieced together.",
                    "Use a VPN when browsing on public Wi-Fi to keep your data private.",
                    "Read privacy policies before signing up for new apps or services to understand how your data is used."
                },
                ["malware"] = new List<string>
                {
                    "Keep your antivirus software updated to protect against the latest malware threats.",
                    "Never download software from unofficial sources — malware is often disguised as free downloads.",
                    "Regularly scan your system for malware, especially after visiting unfamiliar websites.",
                    "Be wary of USB drives from unknown sources — they can carry malware that auto-runs on connection."
                },
                ["vpn"] = new List<string>
                {
                    "A VPN encrypts your internet traffic and masks your IP address, boosting your online privacy.",
                    "Use a reputable, paid VPN service rather than free ones — free VPNs may sell your data.",
                    "A VPN is especially useful on public Wi-Fi networks like coffee shops or airports."
                },
                ["2fa"] = new List<string>
                {
                    "Two-factor authentication adds an extra layer of security beyond just a password.",
                    "Enable 2FA on all your important accounts — email, banking, and social media especially.",
                    "Use an authenticator app rather than SMS for 2FA where possible — it's more secure."
                },
                ["hacker"] = new List<string>
                {
                    "Keep all software updated to patch vulnerabilities that hackers exploit.",
                    "Use strong, unique passwords and 2FA to make your accounts much harder to compromise.",
                    "Be careful what you click — many hacking attempts start with social engineering, not technical attacks."
                },
                ["ransomware"] = new List<string>
                {
                    "Back up your data regularly to an offline or cloud location to protect against ransomware.",
                    "Never open suspicious email attachments — ransomware is often delivered via phishing emails.",
                    "Keep your operating system and software up to date to reduce ransomware vulnerability."
                },
                ["links"] = new List<string>
                {
                    "Hover over links before clicking to preview the actual URL destination.",
                    "Avoid shortened URLs from untrusted sources — use an URL expander to see where they lead.",
                    "Look for HTTPS and a padlock icon in your browser before entering any sensitive information."
                },
                ["wifi"] = new List<string>
                {
                    "Avoid accessing sensitive accounts on public Wi-Fi without using a VPN.",
                    "Use WPA3 or WPA2 encryption on your home router and change the default password.",
                    "Turn off Wi-Fi auto-connect to prevent your device from joining rogue hotspots."
                },
                ["social engineering"] = new List<string>
                {
                    "Social engineering exploits human psychology rather than technical vulnerabilities — stay sceptical.",
                    "Always verify requests for sensitive information through official channels, even if they seem legitimate.",
                    "Train yourself to pause and verify before acting on any unexpected or urgent request."
                }
            };

        // ── Follow-up / conversation flow triggers ────────────────────────────────
        private readonly List<string> _followUpTriggers = new List<string>
        {
            "tell me more", "explain more", "give me another tip", "another tip",
            "more info", "more details", "more", "go on", "continue", "elaborate"
        };

        // ── Sentiment keyword maps ────────────────────────────────────────────────
        private readonly Dictionary<string, SentimentType> _sentimentKeywords =
            new Dictionary<string, SentimentType>(StringComparer.OrdinalIgnoreCase)
            {
                ["worried"] = SentimentType.Worried,
                ["scared"] = SentimentType.Worried,
                ["afraid"] = SentimentType.Worried,
                ["nervous"] = SentimentType.Worried,
                ["anxious"] = SentimentType.Worried,
                ["concerned"] = SentimentType.Worried,
                ["curious"] = SentimentType.Curious,
                ["wondering"] = SentimentType.Curious,
                ["interested"] = SentimentType.Curious,
                ["want to know"] = SentimentType.Curious,
                ["frustrated"] = SentimentType.Frustrated,
                ["confused"] = SentimentType.Frustrated,
                ["don't understand"] = SentimentType.Frustrated,
                ["lost"] = SentimentType.Frustrated,
                ["annoyed"] = SentimentType.Frustrated,
                ["great"] = SentimentType.Positive,
                ["thanks"] = SentimentType.Positive,
                ["thank you"] = SentimentType.Positive,
                ["awesome"] = SentimentType.Positive,
                ["helpful"] = SentimentType.Positive,
                ["love"] = SentimentType.Positive
            };

        // ── Public: set user name from the name prompt ────────────────────────────
        public void SetUserName(string name)
        {
            _memory.Name = name;
        }

        public string GetUserName() => _memory.Name;

        // ── Process a message and return a reply ──────────────────────────────────
        public string ProcessMessage(string input)
        {
            if (string.IsNullOrWhiteSpace(input))
                return "Please type something so I can help you!";

            _memory.QuestionCount++;
            string lower = input.ToLower().Trim();

            // Detect sentiment first
            SentimentType sentiment = DetectSentiment(lower);

            string response = BuildResponse(lower, sentiment);

            // Fire the delegate event
            OnResponseGenerated?.Invoke(response, sentiment);

            return response;
        }

        // ── Build the response ────────────────────────────────────────────────────
        private string BuildResponse(string lower, SentimentType sentiment)
        {
            string namePrefix = string.IsNullOrEmpty(_memory.Name) ? "" : $"{_memory.Name}, ";

            // ── Greetings ─────────────────────────────────────────────────────────
            if (lower == "hello" || lower == "hi" || lower == "hey")
                return $"Hey {_memory.Name}! 👋 Ask me anything about cybersecurity — passwords, phishing, privacy, and more!";

            if (lower.Contains("how are you"))
                return "I'm running at full security capacity! 🛡️ Ready to help you stay safe online.";

            if (lower.Contains("what is your purpose") || lower.Contains("what do you do") || lower == "purpose")
                return "I'm your Cybersecurity Awareness Chatbot! I help you understand threats like phishing, malware, and scams — and how to stay safe online.";

            // ── Memory: favourite topic ────────────────────────────────────────────
            if (lower.Contains("i'm interested in") || lower.Contains("i am interested in"))
            {
                foreach (var keyword in _keywordResponses.Keys)
                {
                    if (lower.Contains(keyword))
                    {
                        _memory.FavouriteTopic = keyword;
                        return $"Great! I'll remember that you're interested in {keyword}. It's a crucial part of staying safe online. Feel free to ask me anything about {keyword}!";
                    }
                }
                // Generic interest capture
                string topic = lower.Replace("i'm interested in", "").Replace("i am interested in", "").Trim();
                _memory.FavouriteTopic = topic;
                return $"Great! I'll remember you're interested in {topic}. Ask me any cybersecurity question!";
            }

            // ── Follow-up / conversation flow ─────────────────────────────────────
            if (_followUpTriggers.Any(t => lower.Contains(t)))
            {
                if (!string.IsNullOrEmpty(_memory.LastTopic) && _keywordResponses.ContainsKey(_memory.LastTopic))
                {
                    var responses = _keywordResponses[_memory.LastTopic];
                    string tip = responses[_random.Next(responses.Count)];
                    return $"Here's another tip on {_memory.LastTopic}: {tip}";
                }
                return "Sure! Could you remind me which topic you'd like more info on? (e.g. passwords, phishing, privacy)";
            }

            // ── Sentiment-adjusted response prefix ────────────────────────────────
            string sentimentPrefix = GetSentimentPrefix(sentiment, namePrefix);

            // ── Keyword matching ──────────────────────────────────────────────────
            foreach (var kvp in _keywordResponses)
            {
                if (lower.Contains(kvp.Key))
                {
                    _memory.LastTopic = kvp.Key;
                    if (!_memory.MentionedTopics.Contains(kvp.Key))
                        _memory.MentionedTopics.Add(kvp.Key);

                    string tip = kvp.Value[_random.Next(kvp.Value.Count)];

                    // Memory: personalise if favourite topic
                    string personalise = "";
                    if (!string.IsNullOrEmpty(_memory.FavouriteTopic) &&
                        _memory.FavouriteTopic.Equals(kvp.Key, StringComparison.OrdinalIgnoreCase))
                        personalise = $" As someone interested in {kvp.Key}, this is especially relevant for you.";

                    return $"{sentimentPrefix}{tip}{personalise}";
                }
            }

            // ── Memory recall: use topic in question ──────────────────────────────
            if (!string.IsNullOrEmpty(_memory.FavouriteTopic) &&
                lower.Contains(_memory.FavouriteTopic))
            {
                return $"As someone interested in {_memory.FavouriteTopic}, here's a tip: " +
                       $"{_keywordResponses.ContainsKey(_memory.FavouriteTopic) ? _keywordResponses[_memory.FavouriteTopic][_random.Next(_keywordResponses[_memory.FavouriteTopic].Count)] : "Stay informed and stay safe!"}";
            }

            // ── Help ──────────────────────────────────────────────────────────────
            if (lower == "help" || lower == "topics" || lower == "what can you do")
            {
                string topics = string.Join(", ", _keywordResponses.Keys);
                return $"I can help with these cybersecurity topics: {topics}. Just type any topic or ask a question!";
            }

            // ── Unknown input (error handling) ────────────────────────────────────
            return $"I'm not sure I understand. Can you try rephrasing? You can ask about: passwords, phishing, scams, privacy, malware, VPN, 2FA, ransomware, links, or WiFi. Type 'help' to see all topics.";
        }

        // ── Detect sentiment from user input ──────────────────────────────────────
        public SentimentType DetectSentiment(string lower)
        {
            foreach (var kvp in _sentimentKeywords)
            {
                if (lower.Contains(kvp.Key))
                    return kvp.Value;
            }
            return SentimentType.Neutral;
        }

        // ── Get an empathetic prefix based on sentiment ───────────────────────────
        private string GetSentimentPrefix(SentimentType sentiment, string namePrefix)
        {
            switch (sentiment)
            {
                case SentimentType.Worried:
                    return $"It's completely understandable to feel that way, {_memory.Name}. Scammers can be very convincing. Let me share some tips to help you stay safe. ";
                case SentimentType.Curious:
                    return $"Great curiosity, {_memory.Name}! Learning about this is the first step to staying safe. ";
                case SentimentType.Frustrated:
                    return $"I understand this can feel overwhelming, {_memory.Name}. Let me simplify it for you. ";
                case SentimentType.Positive:
                    return $"Glad you're engaged, {_memory.Name}! ";
                default:
                    return string.IsNullOrEmpty(_memory.Name) ? "" : $"{_memory.Name}, ";
            }
        }

        public UserMemory GetMemory() => _memory;
    }
}
