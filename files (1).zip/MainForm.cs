using System;
using System.Drawing;
using System.Media;
using System.Windows.Forms;

namespace CybersecurityChatbot
{
    public partial class MainForm : Form
    {
        private readonly ChatBot _bot = new ChatBot();
        private bool _nameEntered = false;

        // ── Controls ──────────────────────────────────────────────────────────────
        private Panel pnlHeader;
        private Label lblAsciiArt;
        private Label lblTitle;
        private Label lblSubtitle;

        private Panel pnlChat;
        private RichTextBox rtbChat;

        private Panel pnlInput;
        private TextBox txtInput;
        private Button btnSend;
        private Button btnClear;

        private Panel pnlStatus;
        private Label lblStatus;
        private Label lblSentiment;
        private Label lblMemory;

        // ── Colour palette ────────────────────────────────────────────────────────
        private static readonly Color BgDark      = Color.FromArgb(10,  14,  20);
        private static readonly Color BgCard      = Color.FromArgb(16,  22,  32);
        private static readonly Color BgPanel     = Color.FromArgb(20,  28,  40);
        private static readonly Color AccentCyan  = Color.FromArgb(0,  212, 255);
        private static readonly Color AccentGreen = Color.FromArgb(57, 255, 100);
        private static readonly Color AccentAmber = Color.FromArgb(255, 191,  0);
        private static readonly Color AccentRed   = Color.FromArgb(255,  70,  70);
        private static readonly Color TextPrimary = Color.FromArgb(220, 235, 255);
        private static readonly Color TextMuted   = Color.FromArgb(100, 130, 170);
        private static readonly Color BorderColor = Color.FromArgb(35,  55,  80);

        public MainForm()
        {
            InitializeComponent();
            BuildUI();
            WireEvents();
            PlayWelcomeSound();
            ShowWelcome();
        }

        // ── Build the entire UI in code (no .Designer file needed) ───────────────
        private void BuildUI()
        {
            // ── Form ──────────────────────────────────────────────────────────────
            this.Text = "CyberBot — Cybersecurity Awareness Assistant";
            this.Size = new Size(900, 720);
            this.MinimumSize = new Size(720, 560);
            this.BackColor = BgDark;
            this.ForeColor = TextPrimary;
            this.Font = new Font("Consolas", 9.5f);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.Sizable;

            // ── Header ────────────────────────────────────────────────────────────
            pnlHeader = new Panel
            {
                Dock = DockStyle.Top,
                Height = 130,
                BackColor = BgCard,
                Padding = new Padding(14, 8, 14, 8)
            };

            lblAsciiArt = new Label
            {
                Text =
                    "  ██████╗██╗   ██╗██████╗ ███████╗██████╗ ██████╗  ██████╗ ████████╗\n" +
                    " ██╔════╝╚██╗ ██╔╝██╔══██╗██╔════╝██╔══██╗██╔══██╗██╔═══██╗╚══██╔══╝\n" +
                    " ██║      ╚████╔╝ ██████╔╝█████╗  ██████╔╝██████╔╝██║   ██║   ██║   \n" +
                    " ██║       ╚██╔╝  ██╔══██╗██╔══╝  ██╔══██╗██╔══██╗██║   ██║   ██║   \n" +
                    " ╚██████╗   ██║   ██████╔╝███████╗██║  ██║██████╔╝╚██████╔╝   ██║   \n" +
                    "  ╚═════╝   ╚═╝   ╚═════╝ ╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝   ╚═╝   ",
                Font = new Font("Consolas", 5.8f, FontStyle.Bold),
                ForeColor = AccentCyan,
                AutoSize = false,
                TextAlign = ContentAlignment.MiddleLeft,
                Dock = DockStyle.Fill,
                BackColor = Color.Transparent
            };

            lblTitle = new Label
            {
                Text = "🛡  CYBERSECURITY AWARENESS CHATBOT",
                Font = new Font("Consolas", 13f, FontStyle.Bold),
                ForeColor = AccentCyan,
                AutoSize = false,
                Height = 28,
                Dock = DockStyle.Top,
                TextAlign = ContentAlignment.MiddleCenter,
                BackColor = Color.Transparent
            };

            lblSubtitle = new Label
            {
                Text = "Your intelligent guide to staying safe in the digital world",
                Font = new Font("Consolas", 8.5f, FontStyle.Italic),
                ForeColor = TextMuted,
                AutoSize = false,
                Height = 18,
                Dock = DockStyle.Bottom,
                TextAlign = ContentAlignment.MiddleCenter,
                BackColor = Color.Transparent
            };

            pnlHeader.Controls.Add(lblAsciiArt);
            pnlHeader.Controls.Add(lblTitle);
            pnlHeader.Controls.Add(lblSubtitle);

            // ── Status bar (bottom) ───────────────────────────────────────────────
            pnlStatus = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 32,
                BackColor = BgCard,
                Padding = new Padding(10, 0, 10, 0)
            };

            lblStatus = new Label
            {
                Text = "● ONLINE",
                Font = new Font("Consolas", 8.5f, FontStyle.Bold),
                ForeColor = AccentGreen,
                AutoSize = true,
                Location = new Point(10, 8)
            };

            lblSentiment = new Label
            {
                Text = "MOOD: Neutral",
                Font = new Font("Consolas", 8.5f),
                ForeColor = TextMuted,
                AutoSize = true,
                Location = new Point(120, 8)
            };

            lblMemory = new Label
            {
                Text = "MEMORY: Empty",
                Font = new Font("Consolas", 8.5f),
                ForeColor = TextMuted,
                AutoSize = true,
                Location = new Point(280, 8)
            };

            pnlStatus.Controls.AddRange(new Control[] { lblStatus, lblSentiment, lblMemory });

            // ── Input panel ───────────────────────────────────────────────────────
            pnlInput = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 60,
                BackColor = BgPanel,
                Padding = new Padding(12, 10, 12, 10)
            };

            btnClear = new Button
            {
                Text = "CLEAR",
                Width = 75,
                Dock = DockStyle.Right,
                FlatStyle = FlatStyle.Flat,
                BackColor = BgCard,
                ForeColor = TextMuted,
                Font = new Font("Consolas", 8.5f, FontStyle.Bold),
                Cursor = Cursors.Hand,
                Margin = new Padding(4, 0, 0, 0)
            };
            btnClear.FlatAppearance.BorderColor = BorderColor;
            btnClear.FlatAppearance.MouseOverBackColor = Color.FromArgb(30, 45, 65);

            btnSend = new Button
            {
                Text = "SEND  ▶",
                Width = 100,
                Dock = DockStyle.Right,
                FlatStyle = FlatStyle.Flat,
                BackColor = AccentCyan,
                ForeColor = BgDark,
                Font = new Font("Consolas", 9f, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnSend.FlatAppearance.BorderSize = 0;
            btnSend.FlatAppearance.MouseOverBackColor = Color.FromArgb(0, 180, 220);

            txtInput = new TextBox
            {
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(25, 35, 50),
                ForeColor = TextPrimary,
                Font = new Font("Consolas", 10f),
                BorderStyle = BorderStyle.None,
                Margin = new Padding(0, 2, 8, 2)
            };

            pnlInput.Controls.Add(txtInput);
            pnlInput.Controls.Add(btnSend);
            pnlInput.Controls.Add(btnClear);

            // ── Chat area ─────────────────────────────────────────────────────────
            pnlChat = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = BgDark,
                Padding = new Padding(12, 8, 12, 8)
            };

            rtbChat = new RichTextBox
            {
                Dock = DockStyle.Fill,
                BackColor = BgDark,
                ForeColor = TextPrimary,
                Font = new Font("Consolas", 9.5f),
                ReadOnly = true,
                BorderStyle = BorderStyle.None,
                ScrollBars = RichTextBoxScrollBars.Vertical,
                WordWrap = true
            };

            pnlChat.Controls.Add(rtbChat);

            // ── Compose form ──────────────────────────────────────────────────────
            this.Controls.Add(pnlChat);
            this.Controls.Add(pnlInput);
            this.Controls.Add(pnlStatus);
            this.Controls.Add(pnlHeader);
        }

        // ── Wire events ───────────────────────────────────────────────────────────
        private void WireEvents()
        {
            btnSend.Click += BtnSend_Click;
            btnClear.Click += (s, e) => rtbChat.Clear();
            txtInput.KeyDown += (s, e) =>
            {
                if (e.KeyCode == Keys.Enter)
                {
                    e.SuppressKeyPress = true;
                    BtnSend_Click(s, e);
                }
            };

            // Hook delegate event from ChatBot
            _bot.OnResponseGenerated += (response, sentiment) =>
            {
                UpdateSentimentLabel(sentiment);
            };
        }

        // ── Send message handler ──────────────────────────────────────────────────
        private void BtnSend_Click(object sender, EventArgs e)
        {
            string input = txtInput.Text.Trim();
            if (string.IsNullOrWhiteSpace(input)) return;

            txtInput.Clear();

            if (!_nameEntered)
            {
                // First message is the user's name
                if (string.IsNullOrWhiteSpace(input))
                {
                    AppendMessage("BOT", "Please enter a valid name to continue.", AccentAmber);
                    return;
                }
                _bot.SetUserName(input);
                _nameEntered = true;
                AppendMessage("YOU", input, AccentCyan);
                AppendMessage("BOT",
                    $"Hello {input}! 👋 Welcome to the Cybersecurity Awareness Chatbot.\n" +
                    "You can ask me about: passwords, phishing, scams, privacy, malware, VPN, 2FA, ransomware, links, or WiFi.\n" +
                    "Type 'help' for a full topic list.",
                    AccentGreen);
                UpdateMemoryLabel();
                return;
            }

            AppendMessage("YOU", input, AccentCyan);
            string response = _bot.ProcessMessage(input);
            AppendMessage("BOT", response, AccentGreen);
            UpdateMemoryLabel();
        }

        // ── Append a styled message to the chat ───────────────────────────────────
        private void AppendMessage(string speaker, string message, Color speakerColor)
        {
            rtbChat.SuspendLayout();

            // Timestamp
            rtbChat.SelectionStart = rtbChat.TextLength;
            rtbChat.SelectionLength = 0;
            rtbChat.SelectionColor = TextMuted;
            rtbChat.AppendText($"\n[{DateTime.Now:HH:mm:ss}] ");

            // Speaker label
            rtbChat.SelectionColor = speakerColor;
            rtbChat.SelectionFont = new Font("Consolas", 9.5f, FontStyle.Bold);
            rtbChat.AppendText($"{speaker}: ");

            // Message body
            rtbChat.SelectionColor = TextPrimary;
            rtbChat.SelectionFont = new Font("Consolas", 9.5f, FontStyle.Regular);
            rtbChat.AppendText(message + "\n");

            rtbChat.ResumeLayout();
            rtbChat.ScrollToCaret();
        }

        // ── Update sentiment label in status bar ──────────────────────────────────
        private void UpdateSentimentLabel(SentimentType sentiment)
        {
            string icon;
            Color colour;
            switch (sentiment)
            {
                case SentimentType.Worried:    icon = "😟 Worried";    colour = AccentAmber; break;
                case SentimentType.Curious:    icon = "🤔 Curious";    colour = AccentCyan;  break;
                case SentimentType.Frustrated: icon = "😤 Frustrated"; colour = AccentRed;   break;
                case SentimentType.Positive:   icon = "😊 Positive";   colour = AccentGreen; break;
                default:                       icon = "😐 Neutral";    colour = TextMuted;   break;
            }
            lblSentiment.Text = $"MOOD: {icon}";
            lblSentiment.ForeColor = colour;
        }

        // ── Update memory label in status bar ────────────────────────────────────
        private void UpdateMemoryLabel()
        {
            var mem = _bot.GetMemory();
            string topic = string.IsNullOrEmpty(mem.FavouriteTopic) ? "none" : mem.FavouriteTopic;
            lblMemory.Text = $"MEMORY: topic={topic} | questions={mem.QuestionCount}";
            lblMemory.ForeColor = string.IsNullOrEmpty(mem.FavouriteTopic) ? TextMuted : AccentCyan;
        }

        // ── Play welcome WAV (same as Part 1) ────────────────────────────────────
        private void PlayWelcomeSound()
        {
            try
            {
                SoundPlayer player = new SoundPlayer("welcome.wav");
                player.Play();
            }
            catch { /* WAV optional — graceful skip */ }
        }

        // ── Show initial welcome prompt ───────────────────────────────────────────
        private void ShowWelcome()
        {
            AppendMessage("BOT",
                "╔══════════════════════════════════════════════════════╗\n" +
                "║   Welcome to the Cybersecurity Awareness Chatbot!   ║\n" +
                "╚══════════════════════════════════════════════════════╝\n" +
                "Before we begin, what is your name?",
                AccentCyan);
        }

        // ── Required by partial class pattern ────────────────────────────────────
        private void InitializeComponent()
        {
            this.SuspendLayout();
            this.AutoScaleDimensions = new SizeF(7F, 15F);
            this.AutoScaleMode = AutoScaleMode.Font;
            this.ResumeLayout(false);
        }
    }
}
