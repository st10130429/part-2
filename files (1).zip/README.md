# PROG6221 POE – Part 2
## Cybersecurity Awareness Chatbot — WinForms GUI

---

### Overview

This is Part 2 of the PROG6221 Portfolio of Evidence. It expands the Part 1 console chatbot into a **WinForms GUI application** with the following features:

---

### Features Implemented

| # | Requirement | Implementation |
|---|-------------|----------------|
| 1 | **GUI Design & Implementation** | Dark cyber-themed WinForms app with coloured chat, header with ASCII art, status bar, and proper spacing |
| 2 | **Keyword Recognition** | Dictionary-based matching for 12+ cybersecurity keywords (password, phishing, scam, privacy, malware, VPN, 2FA, ransomware, links, WiFi, hacker, social engineering) |
| 3 | **Random Responses** | Each keyword maps to a `List<string>` of 3–4 responses; one is randomly selected per query using `Random` |
| 4 | **Conversation Flow** | Follow-up triggers ("tell me more", "explain more", "give me another tip") continue the last topic without restarting |
| 5 | **Memory & Recall** | `UserMemory` class stores user name, favourite topic, mentioned topics, last topic, and question count. Bot personalises responses using this data |
| 6 | **Sentiment Detection** | Detects "worried", "curious", "frustrated", "positive" and adjusts responses with empathetic prefixes. Sentiment shown in status bar |
| 7 | **Error Handling** | Default fallback for unknown inputs: *"I'm not sure I understand. Can you try rephrasing?"*. No crashes on unexpected input |
| 8 | **Code Optimisation** | Uses `Dictionary`, `List`, delegates/events, separate `ChatBot` class, `UserMemory` class, and well-organised methods |

---

### Project Structure

```
CybersecurityChatbot/
├── Program.cs          – Entry point (Application.Run)
├── MainForm.cs         – WinForms GUI (all UI built in code)
├── ChatBot.cs          – All chatbot logic (keywords, memory, sentiment, delegate)
├── CybersecurityChatbot.csproj
├── welcome.wav         – (optional) voice greeting from Part 1
└── README.md
```

---

### How to Run

**Requirements:** Visual Studio 2022 with .NET 6 Windows Desktop workload

1. Open `CybersecurityChatbot.csproj` in Visual Studio 2022
2. Press **F5** or click **Start**
3. The GUI will launch — type your name when prompted, then chat!

**Or via terminal:**
```bash
dotnet run
```

---

### OOP Concepts Used

- **Classes:** `ChatBot`, `UserMemory`, `MainForm`
- **Delegate/Event:** `ResponseGeneratedHandler` delegate and `OnResponseGenerated` event in `ChatBot`
- **Enum:** `SentimentType` (Neutral, Worried, Curious, Frustrated, Positive)
- **Generic Collections:** `Dictionary<string, List<string>>` for keyword responses, `List<string>` for follow-up triggers and memory
- **Encapsulation:** All chatbot state kept inside `ChatBot` and `UserMemory`

---

### GitHub Submission Notes

- Minimum 6 commits with meaningful messages required
- Minimum 2 releases/tags required
- WAV file and README must be included in the repository

---

*PROG6221 – Programming 2A | The IIE | 2026*
